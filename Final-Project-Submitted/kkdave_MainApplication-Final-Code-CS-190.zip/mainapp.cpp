#include <cstdio>
#include <fstream> // file stream for reading/writing files
#include <iostream> // general purpose iostream for printing to terminal
#include <map> // storing the pairs of (word, frequency).
#include <utility> // this package has general purpose algorithms for sorting STL containers
#include <iterator> // this package allows the user to iterate through STL containers
#include <functional> // this package allows the user to modify the STL containers
#include <algorithm> // this package allows the user to use lambda functions
#include <string> // this package allows user to use the multi-purpose and multifunctional c++ strings
#include <vector> // STL container for accumulating and manipulating data
#include <sstream> // string stream for efficient string processing
#include <boost/property_tree/json_parser.hpp>
#include <numeric>
#include <ctime>
#include <ratio>
#include <random>
#include <chrono>
#include <signal.h>
#define COALERT 1000
#define VOCALERT 500
template <typename T>
std::vector<T> as_vector(boost::property_tree::ptree const& pt, boost::property_tree::ptree::key_type const& key)
{
    std::vector<T> r;
    for (auto& item : pt.get_child(key))
        r.push_back(item.second.get_value<T>());
    //std::cout<<"Size of vector = "<<r.size()<<std::endl;
    return r;
} 
typedef std::map<int, time_t>  data_container;
static std::vector<int> carbon_data;
static std::vector<int> voc_data;
static std::vector<int> people_data;
static std::random_device device;
static std::default_random_engine rand_engine{device()};
static std::uniform_int_distribution<int> carbon{400, 900};
static std::uniform_int_distribution<int> voc{0, 150};
static std::uniform_int_distribution<int> people{0, 50};
static std::uniform_int_distribution<time_t> time_dis{0, 0xFFFFFFFF}; 


data_container carbon_data_acc;
data_container voc_data_acc;
data_container people_data_acc;

void init_data()
{
    for(int i=0; i< 1209600; i++)
    {
        carbon_data.push_back(carbon(rand_engine));
        voc_data.push_back(voc(rand_engine));
        people_data.push_back(people(rand_engine));
        carbon_data_acc[carbon(rand_engine)] = time_dis(rand_engine);
        voc_data_acc[voc(rand_engine)] = time_dis(rand_engine);
        people_data_acc[people(rand_engine)] = time_dis(rand_engine);

    }
}
void print_weekly_average()
{
        std::cout<<"--------------->Average Weekly Conditions<-----------------"<<std::endl;
        std::cout<<"Week -1\n"<<std::endl;
        std::cout<<"Average Carbon Dioxide: "<<std::accumulate(carbon_data.begin(), carbon_data.begin()+302399, 0)/302400<<std::endl;
        std::cout<<"Average VoC: "<<std::accumulate(voc_data.begin(),voc_data.begin()+302399, 0)/302400<<std::endl;
        std::cout<<std::endl;
        std::cout<<"Week -2\n"<<std::endl;
        std::cout<<"Average Carbon Dioxide: "<<std::accumulate(carbon_data.begin()+302400, carbon_data.begin()+604799, 0)/302400<<std::endl;
        std::cout<<"Average VoC: "<<std::accumulate(voc_data.begin()+302400,voc_data.begin()+604799, 0)/302400<<std::endl;
        std::cout<<std::endl;
        std::cout<<"Week -3\n"<<std::endl;
        std::cout<<"Average Carbon Dioxide: "<<std::accumulate(carbon_data.begin()+604800, carbon_data.begin()+907199, 0)/302400<<std::endl;
        std::cout<<"Average VoC: "<<std::accumulate(voc_data.begin()+604800,voc_data.begin()+907199, 0)/302400<<std::endl;
        std::cout<<std::endl;
        std::cout<<"Week -4\n"<<std::endl;
        std::cout<<"Average Carbon Dioxide: "<<std::accumulate(carbon_data.begin()+907200, carbon_data.begin()+1209600, 0)/302400<<std::endl;
        std::cout<<"Average VoC: "<<std::accumulate(voc_data.begin()+907200,voc_data.begin()+1209600, 0)/302400<<std::endl;
        std::cout<<std::endl;
}
void print_monthly_average()
{
    std::cout<<"--------------->Average Monthly Conditions<-----------------\n"<<std::endl;
    std::cout<<"Average Carbon Dioxide: "<<std::accumulate(carbon_data.begin(), carbon_data.begin()+1209599, 0)/1209600<<std::endl;
    std::cout<<"Average VoC: "<<std::accumulate(voc_data.begin(),voc_data.begin()+1209599, 0)/1209600<<std::endl;
    std::cout<<std::endl;
}
int main(int argc, char const *argv[])
{
    std::string s;
    bool ok = true;
    int max_people = 0;
    init_data();
    print_weekly_average();
    print_monthly_average();
    while(std::getline(std::cin, s))
    {
        int st,ed;
        if((st= s.find('{')) == std::string::npos || (ed = s.find('}')) == std::string::npos || s.substr(2,8) != "deviceId")
        {
            continue;
        }
        std::string parsed_string = s.substr(st,ed+1);
        
        std::stringstream ss;
        ss << parsed_string;
        boost::property_tree::ptree pt;
        boost::property_tree::read_json(ss, pt);
        carbon_data.push_back(pt.get<int>("Carbon"));
        voc_data.push_back(pt.get<int>("VoC"));
        people_data.push_back(pt.get<int>("People"));
        std::chrono::system_clock::time_point current_time = std::chrono::system_clock::now();
        time_t format_time;
        format_time = std::chrono::system_clock::to_time_t(current_time);

        carbon_data_acc[pt.get<int>("Carbon")] = format_time;
        voc_data_acc[pt.get<int>("VoC")] = format_time;
        people_data_acc[pt.get<int>("People")] = format_time;

        max_people = std::max(max_people, pt.get<int>("People"));
       
        std::cout<<"---------------->Current Conditions<----------------"<<std::endl;
        std::cout<<"Time Now: "<<ctime(&format_time);
        std::cout<<"Current Carbon Dioxide = "<<pt.get<int>("Carbon")<<std::endl;
        std::cout<<"Current VoC = "<<pt.get<int>("VoC")<<std::endl;
        std::cout<<"Current Number of People = "<<pt.get<int>("People")<<std::endl;
        //std::cout<<"Maximum Number of people = "<< max_people<<std::endl;
        std::cout<<"----------------------------------------------------"<<std::endl;
        print_weekly_average();
        print_monthly_average();
        std::cout<<std::endl;

        std::cout<<"------------->Maximum Recorded Numbers<-------------"<<std::endl;
        std::cout<<"Maximum Carbon Dioxide Recorded   = "<<carbon_data_acc.rbegin()->first <<" ppm on "<<ctime(&carbon_data_acc.rbegin()->second)<<std::endl;
        std::cout<<"Maximum VOC Recorded              = "<<voc_data_acc.rbegin()->first << " ppb on "<<ctime(&voc_data_acc.rbegin()->second)<<std::endl;
        std::cout<<"Maximum Number of People Recorded = "<<people_data_acc.rbegin()->first<<" people on "<<ctime(&people_data_acc.rbegin()->second)<<std::endl;
        std::cout<<"---------------------------------------------------\n"<<std::endl; 
        
        if(pt.get<std::string>("Alert") == "true")
        {
            if(pt.get<int>("Carbon") >= COALERT || pt.get<int>("VoC") >= VOCALERT)
            {
                std::cout<<"Dangerous levels of Carbon Dioxide and/or VoC detected, please evacuate and call emergency services, thank you."<<std::endl;
            }
        }

        // std::cout<<"VoC Content = "<<pt.get<std::string>("VoC")<<std::endl;
        // std::cout<<"Alert Triggered = "<<pt.get<std::string>("Alert")<<std::endl;
           
        
    }
    return 0;
}
