#include <Arduino.h>
#include <SoftwareSerial.h>
#include <rgb_lcd.h>
#define TRG1 4
#define TRG2 6
#define ECH1 5 // in
#define ECH2 7 // out
#define REGULATOR A0
#define ADC_REF 5 
#define GROVE_VCC 5
#define FULL_ANGLE 300
#define BUTTON_PIN 8
#define LCD_CONTROL_PIN A1

int total_people;
unsigned long _calib_in;
unsigned long _calib_out;
SoftwareSerial ESPSerial(2,3);
SoftwareSerial AirQualitySerial(9,10);
rgb_lcd lcd;
unsigned char button_state;
unsigned char lcd_state;
int carbon, voc;


unsigned long distance_in()
{
    static unsigned long duration;
    digitalWrite(TRG1, LOW);
    delayMicroseconds(2);

    digitalWrite(TRG1, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRG1, LOW);

    duration = pulseIn(ECH1, HIGH);
    return 0.017*duration;
}
unsigned long distance_out()
{
    static unsigned long duration;
    digitalWrite(TRG2, LOW);
    delayMicroseconds(2);

    digitalWrite(TRG2, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRG2, LOW);

    duration = pulseIn(ECH2, HIGH);
    return 0.017*duration;
}

void calibrate_sensors()
{
    unsigned int count = 20;
    unsigned long in = 1000; unsigned long out = 1000; unsigned long temp = 0;
    while(count--)
    {
        temp = distance_in();
        if(temp < in)
        {
            in = temp;
        }
        temp = distance_out();
        if(temp < out)
        {
            out = temp;
        }
    }
    _calib_in = in;
    _calib_out = out;
}

void setup_sensors()
{
    pinMode(TRG1, OUTPUT);
    pinMode(TRG2, OUTPUT);
    pinMode(ECH1, INPUT);
    pinMode(ECH2, INPUT);
    pinMode(REGULATOR, INPUT);
    pinMode(BUTTON_PIN, INPUT);
    pinMode(LCD_CONTROL_PIN, INPUT);
}
void color_changer()
{
    float voltage;
    int sensor_value = analogRead(REGULATOR);
    voltage = (float)sensor_value*ADC_REF/1023;
    float degrees = (voltage*FULL_ANGLE)/GROVE_VCC;
    int brightness;
    brightness = map(degrees, 0, FULL_ANGLE, 255, 0);
    if(lcd_state == 1)
    {
        lcd.setRGB(brightness/4, brightness/2, brightness);
    }
    
}
void setup() {
    // put your setup code here, to run once:
    Serial.begin(9600);
    ESPSerial.begin(115200);
    AirQualitySerial.begin(115200);
    lcd.begin(16,2);
    lcd.setRGB(64, 135, 249);
    total_people = 0;
    setup_sensors();
    calibrate_sensors();
    button_state = 0;
    carbon = voc = 0;
    lcd_state = 1;

}
void poll_button()
{
    if(digitalRead(BUTTON_PIN) == HIGH)
    {
        if(button_state == 0)
        {
            button_state = 1;
        }
        else
        {
            button_state = 0;
        }
    }
    if(digitalRead(LCD_CONTROL_PIN) == HIGH)
    {
        if(lcd_state == 1)
        {
            lcd_state = 0;
        }
        else
        {
            lcd_state = 1;
        }
    }
    

}
void count_people()
{
    unsigned long temp  = 0;
    temp = distance_in();
    if(temp < _calib_in)
    {
        ++total_people;
    }
    temp = 0;
    temp = distance_out();
    if(temp < _calib_out)
    {
            --total_people;
    }
    if(total_people < 0)
    {
        total_people = 0;
    }
}
void get_air_quality_data()
{
    if(AirQualitySerial.available())
    {
        byte b1,b2;
        b1 = b2 = 0;
        b1 = AirQualitySerial.read();
        b2 = AirQualitySerial.read();
        carbon = b1*256 + b2;
        b1 = AirQualitySerial.read();
        b2 = AirQualitySerial.read();
        voc = b1*256 + b2;
        AirQualitySerial.flush();
    }
}
void loop() {
    
    color_changer();
    count_people();
    ESPSerial.write(total_people/256);
    ESPSerial.write(total_people%256);
    get_air_quality_data();
    poll_button();

    
    if(lcd_state == 1)
    {
        lcd.display();
        lcd.clear();
        if(button_state == 0)
        {
            char buf[16];
            sprintf(buf, "People = %d", total_people);
            lcd.print(buf);

        }
        else
        {

            char buf[16];
            sprintf(buf, "Carbon: %d", carbon);
            lcd.print(buf);
            lcd.setCursor(0,1);
            sprintf(buf, "VOC:    %d", voc);
            lcd.print(buf);
        }
    }
    else
    {
        lcd.noDisplay();
        lcd.setRGB(0,0,0);
    }
    

    
    //Serial.println(total_people);
    
    delay(200);
    // put your main code here, to run repeatedly:
}